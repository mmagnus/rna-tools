Clazz.declarePackage ("javajs.swing");
Clazz.load (["javajs.swing.TableColumn"], "javajs.swing.AbstractTableModel", null, function () {
Clazz.declareInterface (javajs.swing, "AbstractTableModel", javajs.swing.TableColumn);
});
