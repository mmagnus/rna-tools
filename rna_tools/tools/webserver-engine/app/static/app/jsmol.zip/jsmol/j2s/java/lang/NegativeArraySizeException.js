Clazz.load(["java.lang.RuntimeException"],"java.lang.NegativeArraySizeException",null,function(){
c$=Clazz.declareType(java.lang,"NegativeArraySizeException",RuntimeException);
});
