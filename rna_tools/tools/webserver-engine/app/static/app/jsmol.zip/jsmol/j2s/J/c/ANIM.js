Clazz.declarePackage ("J.c");
Clazz.load (["java.lang.Enum"], "J.c.ANIM", null, function () {
c$ = Clazz.declareType (J.c, "ANIM", Enum);
Clazz.defineEnumConstant (c$, "ONCE", 0, []);
Clazz.defineEnumConstant (c$, "LOOP", 1, []);
Clazz.defineEnumConstant (c$, "PALINDROME", 2, []);
});
