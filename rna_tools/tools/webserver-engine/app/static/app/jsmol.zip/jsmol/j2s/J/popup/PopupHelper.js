Clazz.declarePackage ("J.popup");
Clazz.declareInterface (J.popup, "PopupHelper");
