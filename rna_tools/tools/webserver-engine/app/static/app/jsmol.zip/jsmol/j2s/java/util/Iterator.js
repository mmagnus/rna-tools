Clazz.declareInterface(java.util,"Iterator");
