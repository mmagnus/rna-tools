Clazz.load(["java.lang.IncompatibleClassChangeError"],"java.lang.NoSuchMethodError",null,function(){
c$=Clazz.declareType(java.lang,"NoSuchMethodError",IncompatibleClassChangeError);
});
