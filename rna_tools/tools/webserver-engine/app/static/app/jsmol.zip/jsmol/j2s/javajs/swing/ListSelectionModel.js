Clazz.declarePackage ("javajs.swing");
Clazz.declareInterface (javajs.swing, "ListSelectionModel");
