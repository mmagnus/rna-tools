Clazz.declarePackage ("javajs.swing");
Clazz.load (["javajs.awt.LayoutManager"], "javajs.swing.FlowLayout", null, function () {
c$ = Clazz.declareType (javajs.swing, "FlowLayout", javajs.awt.LayoutManager);
});
