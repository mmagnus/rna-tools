Clazz.declarePackage ("javajs.swing");
Clazz.load (["javajs.swing.JMenuItem"], "javajs.swing.JCheckBoxMenuItem", null, function () {
c$ = Clazz.declareType (javajs.swing, "JCheckBoxMenuItem", javajs.swing.JMenuItem);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, javajs.swing.JCheckBoxMenuItem, ["chk", 2]);
});
});
