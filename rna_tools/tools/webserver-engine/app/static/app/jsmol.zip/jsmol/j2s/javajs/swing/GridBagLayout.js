Clazz.declarePackage ("javajs.swing");
Clazz.load (["javajs.awt.LayoutManager"], "javajs.swing.GridBagLayout", null, function () {
c$ = Clazz.declareType (javajs.swing, "GridBagLayout", javajs.awt.LayoutManager);
});
