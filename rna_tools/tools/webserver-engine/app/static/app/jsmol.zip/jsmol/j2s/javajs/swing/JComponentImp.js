Clazz.declarePackage ("javajs.swing");
Clazz.load (["javajs.swing.JComponent"], "javajs.swing.JComponentImp", null, function () {
c$ = Clazz.declareType (javajs.swing, "JComponentImp", javajs.swing.JComponent);
Clazz.overrideMethod (c$, "toHTML", 
function () {
return null;
});
});
