Clazz.declarePackage ("javajs.awt");
Clazz.load (["javajs.awt.LayoutManager"], "javajs.awt.BorderLayout", null, function () {
c$ = Clazz.declareType (javajs.awt, "BorderLayout", javajs.awt.LayoutManager);
Clazz.defineStatics (c$,
"CENTER", "Center",
"NORTH", "North",
"SOUTH", "South",
"EAST", "East",
"WEST", "West");
});
