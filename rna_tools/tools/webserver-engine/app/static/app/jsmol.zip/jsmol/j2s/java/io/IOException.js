Clazz.load(["java.lang.Exception"],"java.io.IOException",null,function(){
c$=Clazz.declareType(java.io,"IOException",Exception);
});
