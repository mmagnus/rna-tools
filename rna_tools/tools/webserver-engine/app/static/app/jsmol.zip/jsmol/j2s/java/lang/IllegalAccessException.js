Clazz.load(["java.lang.Exception"],"java.lang.IllegalAccessException",null,function(){
c$=Clazz.declareType(java.lang,"IllegalAccessException",Exception);
});
