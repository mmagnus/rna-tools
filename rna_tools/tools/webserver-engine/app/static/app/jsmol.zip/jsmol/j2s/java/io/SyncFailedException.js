Clazz.load(["java.io.IOException"],"java.io.SyncFailedException",null,function(){
c$=Clazz.declareType(java.io,"SyncFailedException",java.io.IOException);
});
