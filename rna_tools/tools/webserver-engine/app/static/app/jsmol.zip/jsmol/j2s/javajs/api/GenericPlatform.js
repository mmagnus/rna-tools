Clazz.declarePackage ("javajs.api");
Clazz.load (["javajs.api.FontManager"], "javajs.api.GenericPlatform", null, function () {
c$ = Clazz.declareInterface (javajs.api, "GenericPlatform", javajs.api.FontManager);
Clazz.defineStatics (c$,
"CURSOR_DEFAULT", 0,
"CURSOR_CROSSHAIR", 1,
"CURSOR_WAIT", 3,
"CURSOR_ZOOM", 8,
"CURSOR_HAND", 12,
"CURSOR_MOVE", 13);
});
