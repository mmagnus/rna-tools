Clazz.load(["java.util.Map"],"java.util.SortedMap",null,function(){
Clazz.declareInterface(java.util,"SortedMap",java.util.Map);
});
