Clazz.load(["java.lang.LinkageError"],"java.lang.ClassCircularityError",null,function(){
c$=Clazz.declareType(java.lang,"ClassCircularityError",LinkageError);
});
