Clazz.declarePackage ("javajs.swing");
c$ = Clazz.declareType (javajs.swing, "SwingConstants");
Clazz.defineStatics (c$,
"LEFT", 2,
"CENTER", 0,
"RIGHT", 4);
