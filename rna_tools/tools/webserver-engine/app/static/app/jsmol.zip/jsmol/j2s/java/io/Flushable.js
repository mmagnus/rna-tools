Clazz.declareInterface(java.io,"Flushable");
