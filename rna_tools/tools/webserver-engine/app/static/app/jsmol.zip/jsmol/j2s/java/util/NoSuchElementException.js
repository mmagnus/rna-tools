Clazz.load(["java.lang.RuntimeException"],"java.util.NoSuchElementException",null,function(){
c$=Clazz.declareType(java.util,"NoSuchElementException",RuntimeException);
});
